# tests/test_converter.py
"""Testes unitários para as funções do módulo lib/converter.py."""
import pytest

from lib.converter import (
    celsius_to_fahrenheit,
    fahrenheit_to_celsius,
    celsius_to_kelvin,
    kelvin_to_celsius,
    fahrenheit_to_kelvin,
    kelvin_to_fahrenheit,
    is_water_freezing,
    is_water_boiling,
    get_water_state,
)

ZERO_ABSOLUTO_MSG = "A temperatura não pode estar abaixo do zero absoluto."


# ---------------------------------------------------------------------------
# Conversões entre escalas
# ---------------------------------------------------------------------------

def test_celsius_to_fahrenheit():
    assert celsius_to_fahrenheit(0) == pytest.approx(32)        # congelamento
    assert celsius_to_fahrenheit(100) == pytest.approx(212)     # ebulição
    assert celsius_to_fahrenheit(25) == pytest.approx(77)       # positiva
    assert celsius_to_fahrenheit(-40) == pytest.approx(-40)     # negativa
    assert celsius_to_fahrenheit(-273.15) == pytest.approx(-459.67)


def test_fahrenheit_to_celsius():
    assert fahrenheit_to_celsius(32) == pytest.approx(0)        # congelamento
    assert fahrenheit_to_celsius(212) == pytest.approx(100)     # ebulição
    assert fahrenheit_to_celsius(77) == pytest.approx(25)       # positiva
    assert fahrenheit_to_celsius(-40) == pytest.approx(-40)     # negativa
    assert fahrenheit_to_celsius(-4) == pytest.approx(-20)      # negativa


def test_celsius_to_kelvin():
    assert celsius_to_kelvin(0) == pytest.approx(273.15)        # congelamento
    assert celsius_to_kelvin(100) == pytest.approx(373.15)      # positiva
    assert celsius_to_kelvin(-40) == pytest.approx(233.15)      # negativa
    assert celsius_to_kelvin(-273.15) == pytest.approx(0)       # zero absoluto
    with pytest.raises(ValueError, match=ZERO_ABSOLUTO_MSG):
        celsius_to_kelvin(-274)


def test_kelvin_to_celsius():
    assert kelvin_to_celsius(273.15) == pytest.approx(0)        # congelamento
    assert kelvin_to_celsius(373.15) == pytest.approx(100)      # positiva
    assert kelvin_to_celsius(0) == pytest.approx(-273.15)       # zero absoluto
    with pytest.raises(ValueError, match=ZERO_ABSOLUTO_MSG):
        kelvin_to_celsius(-1)


def test_fahrenheit_to_kelvin():
    assert fahrenheit_to_kelvin(32) == pytest.approx(273.15)    # congelamento
    assert fahrenheit_to_kelvin(212) == pytest.approx(373.15)   # positiva
    assert fahrenheit_to_kelvin(-40) == pytest.approx(233.15)   # negativa
    assert fahrenheit_to_kelvin(-459.67) == pytest.approx(0)    # zero absoluto
    with pytest.raises(ValueError, match=ZERO_ABSOLUTO_MSG):
        fahrenheit_to_kelvin(-460)


def test_kelvin_to_fahrenheit():
    assert kelvin_to_fahrenheit(273.15) == pytest.approx(32)    # congelamento
    assert kelvin_to_fahrenheit(373.15) == pytest.approx(212)   # positiva
    assert kelvin_to_fahrenheit(0) == pytest.approx(-459.67)    # zero absoluto
    with pytest.raises(ValueError, match=ZERO_ABSOLUTO_MSG):
        kelvin_to_fahrenheit(-10)


# ---------------------------------------------------------------------------
# Verificação do estado da água
# ---------------------------------------------------------------------------

def test_is_water_freezing():
    # Ponto de congelamento em todas as escalas
    assert is_water_freezing(0, "celsius") is True
    assert is_water_freezing(32, "fahrenheit") is True
    assert is_water_freezing(273.15, "kelvin") is True
    # A escala não diferencia maiúsculas de minúsculas
    assert is_water_freezing(0, "Celsius") is True
    # Fora do ponto de congelamento
    assert is_water_freezing(10, "celsius") is False
    assert is_water_freezing(-5, "celsius") is False
    assert is_water_freezing(50, "fahrenheit") is False
    assert is_water_freezing(300, "kelvin") is False


def test_is_water_boiling():
    # Ponto de ebulição em todas as escalas
    assert is_water_boiling(100, "celsius") is True
    assert is_water_boiling(212, "fahrenheit") is True
    assert is_water_boiling(373.15, "kelvin") is True
    # Fora do ponto de ebulição
    assert is_water_boiling(99, "celsius") is False
    assert is_water_boiling(32, "fahrenheit") is False
    assert is_water_boiling(273.15, "kelvin") is False


def test_get_water_state_solido():
    assert get_water_state(-10, "celsius") == "Sólido"
    assert get_water_state(14, "fahrenheit") == "Sólido"
    assert get_water_state(200, "kelvin") == "Sólido"


def test_get_water_state_liquido():
    assert get_water_state(25, "celsius") == "Líquido"
    assert get_water_state(77, "fahrenheit") == "Líquido"
    assert get_water_state(300, "kelvin") == "Líquido"


def test_get_water_state_gasoso():
    assert get_water_state(150, "celsius") == "Gasoso"
    assert get_water_state(300, "fahrenheit") == "Gasoso"
    assert get_water_state(400, "kelvin") == "Gasoso"


def test_get_water_state_pontos_de_transicao():
    congelamento = "Sólido/Líquido (ponto de congelamento)"
    ebulicao = "Líquido/Gasoso (ponto de ebulição)"
    assert get_water_state(0, "celsius") == congelamento
    assert get_water_state(32, "fahrenheit") == congelamento
    assert get_water_state(273.15, "kelvin") == congelamento
    assert get_water_state(100, "celsius") == ebulicao
    assert get_water_state(212, "fahrenheit") == ebulicao
    assert get_water_state(373.15, "kelvin") == ebulicao


# ---------------------------------------------------------------------------
# Robustez: tipos inválidos, escalas desconhecidas e zero absoluto
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("funcao", [is_water_freezing, is_water_boiling, get_water_state])
def test_funcoes_de_estado_rejeitam_tipo_invalido(funcao):
    with pytest.raises(TypeError, match="O valor da temperatura deve ser um número."):
        funcao("texto", "celsius")
    with pytest.raises(TypeError):
        funcao(None, "celsius")
    with pytest.raises(TypeError):
        funcao([10], "celsius")


@pytest.mark.parametrize("funcao", [is_water_freezing, is_water_boiling, get_water_state])
def test_funcoes_de_estado_rejeitam_escala_desconhecida(funcao):
    with pytest.raises(ValueError, match="Escala 'litros' desconhecida ou não suportada."):
        funcao(0, "litros")
    with pytest.raises(ValueError, match="desconhecida"):
        funcao(0, "rankine")


@pytest.mark.parametrize("funcao", [is_water_freezing, is_water_boiling, get_water_state])
def test_funcoes_de_estado_rejeitam_abaixo_do_zero_absoluto(funcao):
    with pytest.raises(ValueError, match=ZERO_ABSOLUTO_MSG):
        funcao(-274, "celsius")
    with pytest.raises(ValueError, match=ZERO_ABSOLUTO_MSG):
        funcao(-460, "fahrenheit")
    with pytest.raises(ValueError, match=ZERO_ABSOLUTO_MSG):
        funcao(-1, "kelvin")
