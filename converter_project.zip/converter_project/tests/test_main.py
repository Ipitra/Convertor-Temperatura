# tests/test_main.py
"""Testes dos caminhos de interação do menu em main.py."""
from main import main


def simular_entradas(monkeypatch, entradas):
    """Faz input() devolver, em ordem, cada valor da lista `entradas`."""
    respostas = iter(entradas)
    monkeypatch.setattr("builtins.input", lambda _prompt="": next(respostas))


def test_opcao_1_celsius_para_fahrenheit(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["1", "25", "4"])
    main()
    saida = capsys.readouterr().out
    assert "25.0°C equivale a 77.00°F" in saida


def test_opcao_1_valor_negativo(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["1", "-40", "4"])
    main()
    saida = capsys.readouterr().out
    assert "-40.0°C equivale a -40.00°F" in saida


def test_opcao_2_fahrenheit_para_celsius(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["2", "212", "4"])
    main()
    saida = capsys.readouterr().out
    assert "212.0°F equivale a 100.00°C" in saida


def test_opcao_3_estado_da_agua_em_celsius(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["3", "25", "C", "4"])
    main()
    saida = capsys.readouterr().out
    assert "A 25.0°C, o estado da água é: Líquido" in saida


def test_opcao_3_estado_da_agua_em_fahrenheit(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["3", "14", "f", "4"])
    main()
    saida = capsys.readouterr().out
    assert "A 14.0°F, o estado da água é: Sólido" in saida


def test_opcao_4_sair(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["4"])
    main()
    saida = capsys.readouterr().out
    assert "--- Conversor de Temperatura Interativo ---" in saida
    assert "Obrigado por usar o conversor. Até logo!" in saida


def test_opcao_invalida(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["9", "4"])
    main()
    saida = capsys.readouterr().out
    assert "Opção inválida, por favor tente novamente." in saida
    assert "Obrigado por usar o conversor. Até logo!" in saida


def test_opcao_1_temperatura_nao_numerica(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["1", "abc", "4"])
    main()
    saida = capsys.readouterr().out
    assert "Erro: Por favor, insira um valor numérico válido." in saida


def test_opcao_2_temperatura_nao_numerica(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["2", "quente", "4"])
    main()
    saida = capsys.readouterr().out
    assert "Erro: Por favor, insira um valor numérico válido." in saida


def test_opcao_3_temperatura_nao_numerica(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["3", "xyz", "4"])
    main()
    saida = capsys.readouterr().out
    assert "Erro: Por favor, insira um valor numérico válido para a temperatura." in saida


def test_opcao_3_escala_invalida(monkeypatch, capsys):
    simular_entradas(monkeypatch, ["3", "25", "K", "4"])
    main()
    saida = capsys.readouterr().out
    assert "Erro: Escala inválida. Use 'C' ou 'F'." in saida
